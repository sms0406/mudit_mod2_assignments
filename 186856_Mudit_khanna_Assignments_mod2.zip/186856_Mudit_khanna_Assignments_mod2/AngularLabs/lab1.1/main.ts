import {Smartphone} from './smartPhone';
import {Basicphone} from './basicPhone';
var arry = new Array();
var basicPhone = new Basicphone("Basic");
arry.push(basicPhone);

var smartPhone = new Smartphone("Smart");
arry.push(smartPhone);

for(var i=0;i<arry.length;i++)
{
    arry[i].printMobileDetails();
}

