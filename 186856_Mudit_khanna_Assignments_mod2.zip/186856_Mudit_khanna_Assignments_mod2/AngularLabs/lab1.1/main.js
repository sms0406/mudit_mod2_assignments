"use strict";
exports.__esModule = true;
var smartPhone_1 = require("./smartPhone");
var basicPhone_1 = require("./basicPhone");
var arry = new Array();
var basicPhone = new basicPhone_1.Basicphone("Basic");
arry.push(basicPhone);
var smartPhone = new smartPhone_1.Smartphone("Smart");
arry.push(smartPhone);
for (var i = 0; i < arry.length; i++) {
    arry[i].printMobileDetails();
}
