import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Lab2ex2Component } from './lab2ex2.component';

describe('Lab2ex2Component', () => {
  let component: Lab2ex2Component;
  let fixture: ComponentFixture<Lab2ex2Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Lab2ex2Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Lab2ex2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
