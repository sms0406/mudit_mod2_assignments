import { Component, OnInit } from '@angular/core';
import data from './data/booklist.json'
@Component({
  selector: 'app-lab4',
  templateUrl: './lab4.component.html',
  styleUrls: ['./lab4.component.css']
})
export class Lab4Component implements OnInit {
  employees=data
  constructor() { }

  ngOnInit() {
  }
  searchById(event) {
    this.employees=  this.employees.filter(singleItem =>
     singleItem.id.toLowerCase().includes(event.target.value.toLowerCase())
    )
   }
  searchByTitle(event) {
    this.employees=  this.employees.filter(singleItem =>
     singleItem.title.toLowerCase().includes(event.target.value.toLowerCase())
    )
  }
  searchByAuthor(event) {
    this.employees=  this.employees.filter(singleItem =>
     singleItem.author.toLowerCase().includes(event.target.value.toLowerCase())
    )
   }

   searchByYear(event) {
    this.employees=  this.employees.filter(singleItem =>
     singleItem.year.toLowerCase().includes(event.target.value.toLowerCase())
    )
   }
}
