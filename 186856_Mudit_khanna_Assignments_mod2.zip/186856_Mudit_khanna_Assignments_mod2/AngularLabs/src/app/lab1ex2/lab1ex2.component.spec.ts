import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Lab1ex2Component } from './lab1ex2.component';

describe('Lab1ex2Component', () => {
  let component: Lab1ex2Component;
  let fixture: ComponentFixture<Lab1ex2Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Lab1ex2Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Lab1ex2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
