package labExercise;



import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/list")
public class TrainingListServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
  
    public TrainingListServlet() {
        super();
      
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/databasedemo","root","root");
			String sql = "select * from List";
			PrintWriter pw = response.getWriter();
			ps = con.prepareStatement(sql);
			rs = ps.executeQuery();
			while(rs.next()) {
				pw.print("Hello");
			}
		}
		catch(Exception e) {
			System.out.println("Error Occurred while connecting");
		}
		finally {
			if(con!=null) {
				try {
					ps.close();
					con.close();
				}
				catch(SQLException e) {
					System.out.println("Your Connection is not closed.");
				}
			}
		}

	
	}

}
